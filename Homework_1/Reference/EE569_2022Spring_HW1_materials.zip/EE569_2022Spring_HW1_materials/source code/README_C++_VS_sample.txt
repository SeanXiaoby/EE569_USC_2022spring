# EE569 Homework Assignment #1
# Date: June 1, 2007
# Name: John Smith
# ID: 1234-5678-90
# email: jsmith@usc.edu
#
# Software: Visual Studio 2007
========================================================================
    CONSOLE APPLICATION : [Problem2] Project Overview
========================================================================

This file contains a summary of what you will find in each of the files that
make up your [Problem2] application.

Steps:

1. Open Problem2.sln.
	This is the solution for the project.
2. Open source.cpp.
	This is the main program for the algorithm.
3. All the header files and the source files have already been included in the project. 

4. You may need to change the value in line#17 to adjust the input file type. "-1" for text
   files and "0" for binary files.
5. Change the input file name in line 19 and the output file name in line 20. 

6. Run the program and follow the instructions. 
   

/////////////////////////////////////////////////////////////////////////////
Other standard files:

a.h, b.cpp
    These files are used to [...explanation...].

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses the "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
